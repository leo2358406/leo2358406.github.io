import asyncio
import pygame
import random
import math

# --- Constants ---
WIDTH, HEIGHT = 800, 600
FPS = 60
LANES = 5
LANE_WIDTH = WIDTH // LANES
LANE_X_POS = [(i * LANE_WIDTH) + (LANE_WIDTH // 2) for i in range(LANES)]

# Colors
SAND = (235, 200, 140)
SAND_DARK = (210, 180, 120)
SKY = (135, 206, 235)
CACTUS_GREEN = (34, 139, 34)
SHRUB_GREEN = (60, 160, 60)
RED = (200, 50, 50)
BLUE = (50, 50, 200)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BROWN = (139, 69, 19)

# --- Initialization ---
pygame.init()

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Desert Bull Dodge - Advanced")

clock = pygame.time.Clock()

font_large = pygame.font.SysFont("arial", 60, bold=True)
font_medium = pygame.font.SysFont("arial", 30)
font_small = pygame.font.SysFont("arial", 20)


class Player:
    def __init__(self):
        self.lane = 2
        self.x = LANE_X_POS[self.lane]
        self.y = HEIGHT - 100
        self.width = 40
        self.height = 60
        self.rect = pygame.Rect(
            self.x - 20,
            self.y,
            self.width,
            self.height
        )
        self.jump_timer = 0
        self.is_jumping = False
        self.facing_right = True

    def move(self, direction):
        new_lane = self.lane + direction

        if 0 <= new_lane < LANES:
            self.lane = new_lane
            self.is_jumping = True
            self.jump_timer = 10
            self.facing_right = direction > 0

    def update(self):
        if self.is_jumping:
            self.jump_timer -= 1

            if self.jump_timer <= 0:
                self.is_jumping = False

        target_x = LANE_X_POS[self.lane]
        self.x += (target_x - self.x) * 0.5

        self.rect.centerx = int(self.x)
        self.rect.bottom = int(self.y)

    def draw(self, surface):
        cx, cy = int(self.x), int(self.y)

        bounce = 0

        if self.is_jumping:
            bounce = -15 * math.sin(
                (10 - self.jump_timer) * 0.3
            )

        leg_offset = 5 if self.is_jumping else 0

        # Legs
        pygame.draw.line(
            surface,
            BLACK,
            (cx - 10, cy - 20 + bounce),
            (cx - 10 - leg_offset, cy),
            4
        )

        pygame.draw.line(
            surface,
            BLACK,
            (cx + 10, cy - 20 + bounce),
            (cx + 10 + leg_offset, cy),
            4
        )

        # Body
        pygame.draw.rect(
            surface,
            BLUE,
            (cx - 15, cy - 45 + bounce, 30, 25)
        )

        # Head
        pygame.draw.circle(
            surface,
            (255, 220, 180),
            (cx, cy - 55 + bounce),
            12
        )

        # Eye
        eye_offset = 4 if self.facing_right else -4

        pygame.draw.circle(
            surface,
            BLACK,
            (cx + eye_offset, cy - 58 + bounce),
            2
        )


class Bull:
    def __init__(self, speed, lane):
        self.lane = lane
        self.x = LANE_X_POS[lane]
        self.y = -100
        self.speed = speed
        self.width = 50
        self.height = 40

        self.rect = pygame.Rect(
            self.x - 25,
            self.y,
            self.width,
            self.height
        )

        self.run_cycle = random.random() * 10

    def update(self):
        self.y += self.speed

        self.rect.centerx = int(self.x)
        self.rect.top = int(self.y)

        self.run_cycle += 0.2 * (self.speed / 5)

    def draw(self, surface):
        cx, cy = int(self.x), int(self.y)

        leg_off = math.sin(self.run_cycle) * 10

        # Back legs
        pygame.draw.line(
            surface,
            BLACK,
            (cx - 15, cy + 10),
            (cx - 15, cy + 25 + leg_off),
            4
        )

        pygame.draw.line(
            surface,
            BLACK,
            (cx + 15, cy + 10),
            (cx + 15, cy + 25 - leg_off),
            4
        )

        # Body
        pygame.draw.ellipse(
            surface,
            RED,
            (cx - 25, cy, 50, 30)
        )

        # Front legs
        pygame.draw.line(
            surface,
            BLACK,
            (cx - 10, cy + 10),
            (cx - 10, cy + 25 - leg_off),
            4
        )

        pygame.draw.line(
            surface,
            BLACK,
            (cx + 10, cy + 10),
            (cx + 10, cy + 25 + leg_off),
            4
        )

        # Head
        pygame.draw.circle(
            surface,
            RED,
            (cx, cy - 10),
            15
        )

        # Horns
        pygame.draw.polygon(
            surface,
            WHITE,
            [
                (cx - 10, cy - 15),
                (cx - 20, cy - 25),
                (cx - 5, cy - 10)
            ]
        )

        pygame.draw.polygon(
            surface,
            WHITE,
            [
                (cx + 10, cy - 15),
                (cx + 20, cy - 25),
                (cx + 5, cy - 10)
            ]
        )

        # Eyes
        pygame.draw.circle(
            surface,
            BLACK,
            (cx - 5, cy - 12),
            2
        )

        pygame.draw.circle(
            surface,
            BLACK,
            (cx + 5, cy - 12),
            2
        )


class Scenery:
    def __init__(self):
        self.cacti = []
        self.shrubs = []

        for _ in range(10):
            self.add_cactus(random.randint(0, HEIGHT))

        for _ in range(5):
            self.add_shrub(random.randint(0, HEIGHT))

    def add_cactus(self, y_pos):
        side = random.choice([-1, 1])

        if side == -1:
            x_pos = random.randint(20, 80)
        else:
            x_pos = random.randint(WIDTH - 80, WIDTH - 20)

        self.cacti.append({
            "x": x_pos,
            "y": y_pos,
            "h": random.randint(30, 60)
        })

    def add_shrub(self, y_pos):
        self.shrubs.append({
            "x": random.randint(0, WIDTH),
            "y": y_pos
        })

    def update(self, speed):
        for c in self.cacti:
            c["y"] += speed

        self.cacti = [
            c for c in self.cacti
            if c["y"] < HEIGHT + 100
        ]

        if len(self.cacti) < 10:
            self.add_cactus(-100)

        for s in self.shrubs:
            s["y"] += speed

        self.shrubs = [
            s for s in self.shrubs
            if s["y"] < HEIGHT + 50
        ]

        if len(self.shrubs) < 5:
            self.add_shrub(-50)

    def draw(self, surface):
        surface.fill(SAND)

        # Lane lines
        for i in range(1, LANES):
            pygame.draw.line(
                surface,
                SAND_DARK,
                (i * LANE_WIDTH, 0),
                (i * LANE_WIDTH, HEIGHT),
                2
            )

        # Cacti
        for c in self.cacti:
            pygame.draw.rect(
                surface,
                CACTUS_GREEN,
                (
                    c["x"] - 5,
                    c["y"] - c["h"],
                    10,
                    c["h"]
                )
            )

            if c["h"] > 40:
                pygame.draw.rect(
                    surface,
                    CACTUS_GREEN,
                    (
                        c["x"] - 15,
                        c["y"] - c["h"] + 15,
                        10,
                        5
                    )
                )

                pygame.draw.rect(
                    surface,
                    CACTUS_GREEN,
                    (
                        c["x"] - 15,
                        c["y"] - c["h"] + 5,
                        5,
                        15
                    )
                )

        # Shrubs
        for s in self.shrubs:
            pygame.draw.ellipse(
                surface,
                SHRUB_GREEN,
                (s["x"], s["y"], 30, 15)
            )


def draw_text_centered(text, font, color, y_offset=0):
    surf = font.render(text, True, color)

    rect = surf.get_rect(
        center=(
            WIDTH // 2,
            HEIGHT // 2 + y_offset
        )
    )

    screen.blit(surf, rect)


def get_bull_count_for_speed(speed):
    if speed < 6:
        return 1

    elif 6 <= speed < 8:
        return random.randint(1, 2)

    elif 8 <= speed < 10:
        return random.randint(1, 3)

    elif 10 <= speed < 12:
        return random.randint(2, 3)

    elif 12 <= speed < 15:
        return random.randint(2, 4)

    else:
        return random.randint(3, 4)


def spawn_bulls(bulls, speed):
    count = get_bull_count_for_speed(speed)

    count = min(count, LANES)

    available_lanes = list(range(LANES))

    selected_lanes = random.sample(
        available_lanes,
        count
    )

    for lane in selected_lanes:

        # Don't spawn another bull too close
        # to the top of the same lane.
        if not any(
            b.lane == lane and b.y < 150
            for b in bulls
        ):
            bulls.append(
                Bull(speed, lane)
            )


async def main_menu():
    while True:
        screen.fill(SKY)

        draw_text_centered(
            "DESERT BULL DODGE",
            font_large,
            BROWN,
            -50
        )

        draw_text_centered(
            "Press SPACE to Start",
            font_medium,
            BLACK,
            50
        )

        draw_text_centered(
            "Use A/D or Arrows to Switch Lanes",
            font_small,
            BLACK,
            100
        )

        pygame.display.flip()

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                return False

            if (
                event.type == pygame.KEYDOWN
                and event.key == pygame.K_SPACE
            ):
                return True

        # Important for Pygbag/browser compatibility
        await asyncio.sleep(0)


async def game_loop():
    player = Player()

    bulls = []

    scenery = Scenery()

    score = 0
    bull_speed = 6.0

    # Speed increases every 5 seconds
    SPEED_INTERVAL = 5000
    last_speed_increase = pygame.time.get_ticks()

    spawn_timer = 0

    running = True
    game_over = False

    while running:

        clock.tick(FPS)

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                return False

            if event.type == pygame.KEYDOWN:

                if game_over:

                    if event.key == pygame.K_SPACE:
                        return True

                    if event.key == pygame.K_q:
                        return False

                else:

                    if event.key in (
                        pygame.K_LEFT,
                        pygame.K_a
                    ):
                        player.move(-1)

                    if event.key in (
                        pygame.K_RIGHT,
                        pygame.K_d
                    ):
                        player.move(1)

        if not game_over:

            # --- Speed increase ---
            current_time = pygame.time.get_ticks()

            if (
                current_time - last_speed_increase
                > SPEED_INTERVAL
            ):
                bull_speed += 1.0
                last_speed_increase = current_time

            # --- Scenery ---
            scenery.update(
                bull_speed * 0.5
            )

            # --- Bull spawning ---
            spawn_timer += 1

            spawn_threshold = max(
                15,
                50 - int(bull_speed * 3)
            )

            if spawn_timer > spawn_threshold:
                spawn_bulls(
                    bulls,
                    bull_speed
                )

                spawn_timer = 0

            # --- Player ---
            player.update()

            # --- Bulls ---
            for bull in bulls[:]:

                bull.update()

                hit_box = player.rect.inflate(
                    -10,
                    -10
                )

                if hit_box.colliderect(
                    bull.rect
                ):
                    game_over = True

                if bull.y > HEIGHT:

                    bulls.remove(bull)

                    score += int(bull_speed)

        # --- Drawing ---
        scenery.draw(screen)

        player.draw(screen)

        for bull in bulls:
            bull.draw(screen)

        # Score
        score_text = font_medium.render(
            f"Score: {score}",
            True,
            BLACK
        )

        screen.blit(
            score_text,
            (10, 10)
        )

        # Speed
        speed_text = font_small.render(
            f"Speed: {bull_speed:.1f}",
            True,
            BLACK
        )

        screen.blit(
            speed_text,
            (10, 40)
        )

        # Game over screen
        if game_over:

            overlay = pygame.Surface(
                (WIDTH, HEIGHT)
            )

            overlay.set_alpha(180)
            overlay.fill(SAND_DARK)

            screen.blit(
                overlay,
                (0, 0)
            )

            draw_text_centered(
                "GAME OVER",
                font_large,
                RED,
                -50
            )

            draw_text_centered(
                f"Final Score: {score}",
                font_medium,
                BLACK,
                20
            )

            draw_text_centered(
                "Press SPACE to Restart",
                font_medium,
                BLUE,
                80
            )

            draw_text_centered(
                "Press Q to Quit",
                font_small,
                BLACK,
                130
            )

        pygame.display.flip()

        # CRITICAL:
        # Give the browser time to process events
        # and render the next frame.
        await asyncio.sleep(0)

    return False


async def main():
    """
    Main Pygbag-compatible game entry point.
    """

    while True:

        start_game = await main_menu()

        if not start_game:
            break

        play_again = await game_loop()

        if not play_again:
            break

    pygame.quit()


# Start the game
asyncio.run(main())
